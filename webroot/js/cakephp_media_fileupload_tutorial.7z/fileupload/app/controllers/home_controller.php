<?php 
class HomeController extends AppController {
	
	var $uses = array();
	
	function index() {
		
	}
	
}
?>