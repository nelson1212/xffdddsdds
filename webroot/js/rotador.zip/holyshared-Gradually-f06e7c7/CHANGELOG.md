Changelog
=========================

version 1.1
-------------------------

* It corresponds to Mootools1.3.